﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
string numeroIngresado = "";
int numeroInicial = 0; 
// COMPROBACIÓN QUE EL SIGITO INGRESADO SEA UN VALOR ENTERO Y QUE TENGA 6 O MENOS CIFRAS
while (true)
    {
        Console.WriteLine("Ingrese un número entero: ");
        numeroIngresado = Console.ReadLine();
        int digitos = numeroIngresado.Length; //EVALUA LA CANTIDAD DE CARÁCTERES QUE POSEE LA CADENA INGRESADA, EN ESTE CASO EL NÚMERO A EVALUAR

        if (digitos > 6){
            Console.WriteLine("Ingrese un número menor o igual de 6 dígitos.");
        } else 
        { 
            if(int.TryParse(numeroIngresado, out numeroInicial))
            {
            break;
            }
            else
            {
            Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            }
        }  
        
    }
// DECLARACIÓN DE VARIABLES PARA LA COMPROBACIÓN DE NÚMEROS PRIMOS
    int numeroEvaluado = numeroInicial; 
    int inicialContador = 5; // SE EMPIEZA CON 5 YA QUE YA SE HICIERON PRUEBAS CON 2 Y 3 
    int factoresFinales = 0; 
    bool pruebaPrimo1 = numeroEvaluado > 1 && numeroEvaluado != 2 && numeroEvaluado != 3;  
// EVALUACIÓN DE EXCEPCIÓN PARA LOS NÚMEROS 0,1,2,3
    if (numeroEvaluado == 2 || numeroEvaluado == 3)
    {
        Console.WriteLine("El número ingresado es un número primo.");
    } else if (numeroEvaluado == 1 || numeroEvaluado == 0) 
    { 
        Console.WriteLine("El número ingresado no es un número primo.");
    }
// PROCESO DE EVALUACIÓN CUANDO LOS NÚMEROS NO SON 0,1,2,3
    while (pruebaPrimo1 == true)
    { 
// PROCESO QUE EVALUA SIN SON DIVISIBLES ENTRE MULTIPLOS DEL 2 Y DEL 3, SI SÍ NO SON PRIMOS
        if (numeroEvaluado% 2 == 0 || numeroEvaluado %3 == 0)
        { 
            Console.WriteLine("El número ingresado no es un número primo."); 
            break; 
        } 
        else if(numeroEvaluado%2 != 0 && numeroEvaluado %3 != 0)
// EVALUACIÓN CUANDO NO SON DIVISIBLES ENTRE MULTIPLOS DEL 2 Y 3 
        {
            double numeroEvaluado1 = numeroEvaluado; 
            double cantidadFactorInicial = Math.Pow(numeroEvaluado1,(1.0/2)); 
// SE OBTIENE RAÍZ CUADRADA PARA SABER HASTA QUE VALOR SE DEBE HACER LA PRUEBA DE DIVISIÓN 
            while (inicialContador <= cantidadFactorInicial)
            { 
                if(numeroEvaluado%inicialContador == 0)
                {
// SE SUMA UNA UNIDAD CUANDO SE ENCONTRÓ UN DIVISOR PARA EL NÚMERO
                    factoresFinales = factoresFinales +1; 
                }
                
                inicialContador ++; 
            }
// PRUEBA FINAL: SI POSEE MÁS DE 2 FACTORES ES PRIMO SI NO ES UN NÚMERO PRIMO
                if (factoresFinales>0)
                {
                    Console.WriteLine("El número ingresado no es un número primo"); 
                    break; 
                }
                else 
                {
                    Console.WriteLine("El número ingresado es un número primo"); 
                    break; 
                }
        } 
        
    } 
// SE FINALIZA EL PROCESO