using System;

namespace Semana4
{
    class Program 
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese primer número: ");
            int num1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo número: ");
            int num2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el tercer número: ");
            int num3 = Convert.ToDouble(Console.ReadLine());
            
            if(num1 > num2)
            {
                Console.WriteLine("Número mayor:" num1);
            }
            if(num1 < num2)
            {
                Console.WriteLine("Número menor:" num1);
            } 
            if(num2 > num1)
            {
                Console.WriteLine("Número mayor:" num2);
            }
            if(num2 < num1)
            {
                Console.WriteLine("Número menor:" num2);
            } 
            if(num3 > num1)
            {
                Console.WriteLine("Número mayor:" num3);
            }
            if(num3 < num1)
            {
                Console.WriteLine("Número menor:" num3);
            } 

            Console.ReadKey(); 
        }
    }
}
